package kr.co.ccrent.reserve.service;

public interface ReserveService {

}
