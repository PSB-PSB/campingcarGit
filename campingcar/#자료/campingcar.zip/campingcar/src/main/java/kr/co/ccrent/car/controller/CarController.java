package kr.co.ccrent.car.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.ccrent.car.service.CarService;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/car")
@RequiredArgsConstructor
public class CarController {

	private final CarService carService;
	
	@GetMapping("list")
	public void listGET(Model model) {
		System.out.println("<Controller> list GEt ==================");
		model.addAttribute("time", carService.getTime());
	}
}
