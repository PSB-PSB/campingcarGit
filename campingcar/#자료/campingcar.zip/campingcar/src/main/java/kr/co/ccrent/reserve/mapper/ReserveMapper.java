package kr.co.ccrent.reserve.mapper;

public interface ReserveMapper {

}
