package kr.co.ccrent.reserve.dto;

public class ReserveDTO {

}
