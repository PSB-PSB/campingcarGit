package kr.co.ccrent.car.service;

public interface CarService {
	String getTime();
}
