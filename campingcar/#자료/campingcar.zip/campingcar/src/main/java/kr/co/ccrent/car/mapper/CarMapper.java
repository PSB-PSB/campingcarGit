package kr.co.ccrent.car.mapper;

public interface CarMapper {
	String selectTime();
}
