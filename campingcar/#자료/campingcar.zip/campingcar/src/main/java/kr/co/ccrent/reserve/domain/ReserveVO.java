package kr.co.ccrent.reserve.domain;

public class ReserveVO {

}
