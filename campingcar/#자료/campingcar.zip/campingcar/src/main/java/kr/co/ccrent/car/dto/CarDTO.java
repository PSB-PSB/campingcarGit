package kr.co.ccrent.car.dto;

public class CarDTO {

}
