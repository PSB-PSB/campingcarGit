package kr.co.ccrent.car.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import kr.co.ccrent.car.mapper.CarMapper;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CarServiceImpl implements CarService {

	private final CarMapper carMapper;
	private final ModelMapper modelMapper;
	
	@Override
	public String getTime() {
		return carMapper.selectTime();
	}

}
