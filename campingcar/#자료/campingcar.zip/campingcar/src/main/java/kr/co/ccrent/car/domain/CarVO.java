package kr.co.ccrent.car.domain;

public class CarVO {

}
